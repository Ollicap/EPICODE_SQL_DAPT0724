CREATE DATABASE toysgroupdb;
USE toysgroupdb;

-- Task 2: Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. Implementa fisicamente le tabelle utilizzando il DBMS SQL Server(o altro).
-- Create tables

CREATE TABLE category
(category_id SMALLINT UNIQUE NOT NULL,
category_name VARCHAR(30) NOT NULL,
CONSTRAINT categoryPK PRIMARY KEY (category_id));

CREATE TABLE products
(product_id INT UNIQUE NOT NULL,
product_name VARCHAR(50) NOT NULL,
category_id SMALLINT NOT NULL,
CONSTRAINT product_PK PRIMARY KEY (product_id),
CONSTRAINT product_categoryFK FOREIGN KEY (category_id) REFERENCES category (category_id));

CREATE TABLE sales_region 
(sales_region_id TINYINT UNIQUE NOT NULL,
sales_region_name VARCHAR(20) NOT NULL,
CONSTRAINT sales_regionPK PRIMARY KEY (sales_region_id));

CREATE TABLE region
(country_id SMALLINT UNIQUE NOT NULL,
country_name VARCHAR(35) NOT NULL,
sales_region_id TINYINT NOT NULL,
CONSTRAINT regionPK PRIMARY KEY (country_id),
CONSTRAINT region_sales_regionFK FOREIGN KEY (sales_region_id) REFERENCES sales_region (sales_region_id));

CREATE TABLE toysales
(order_number VARCHAR(20) NOT NULL,
order_linenumber TINYINT NOT NULL,
order_date DATE NOT NULL,
product_id INT NOT NULL,
quantity TINYINT NOT NULL,
sales_amount DECIMAL(5,2) NOT NULL,
country_id SMALLINT NOT NULL,
CONSTRAINT salesPK PRIMARY KEY (order_number, order_linenumber),
CONSTRAINT salesproductFK FOREIGN KEY (product_id) REFERENCES products (product_id),
CONSTRAINT salesregionFK FOREIGN KEY (country_id) REFERENCES region (country_id));

-- Task 3: Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate) 
-- Populate tables
-- category table
INSERT INTO category (category_id, category_name) VALUES
(1, 'Action Figures'),
(2, 'Building Sets'),
(3, 'Dolls'),
(4, 'Educational Toys'),
(5, 'Electronic Toys'),
(6, 'Games & Puzzles'),
(7, 'Outdoor Play'),
(8, 'Plush Toys'),
(9, 'Pretend Play'),
(10, 'Ride-Ons'),
(11, 'Sports Toys'),
(12, 'Stuffed Animals'),
(13, 'Toy Cars & Trucks'),
(14, 'Toy Instruments'),
(15, 'Toy Vehicles'),
(16, 'Water Toys'),
(17, 'Wooden Toys'),
(18, 'Arts & Crafts'),
(19, 'Science Kits'),
(20, 'Musical Toys');

-- products table

INSERT INTO products (product_id, product_name, category_id) VALUES
(1, 'Dragon Slayer', 1),
(2, 'Mystic Warrior', 1),
(3, 'Galactic Hero', 1),
(4, 'Shadow Ninja', 1),
(5, 'Castle Builder', 2),
(6, 'Space Explorer', 2),
(7, 'Pirate Adventure', 2),
(8, 'Princess Dream', 3),
(9, 'Fairy Tale', 3),
(10, 'Mermaid Magic', 3),
(11, 'Alphabet Explorer', 4),
(12, 'Number Wizard', 4),
(13, 'Shape Shifter', 4),
(14, 'Robo Buddy', 5),
(15, 'Tech Genius', 5),
(16, 'Gadget Guru', 5),
(17, 'Mystery Quest', 6),
(18, 'Card Master', 6),
(19, 'Puzzle Pro', 6),
(20, 'Brain Teaser', 6),
(21, 'Slide Master', 7),
(22, 'Swing King', 7),
(23, 'Sand Castle', 7),
(24, 'Cuddle Bear', 8),
(25, 'Fluffy Bunny', 8),
(26, 'Soft Kitty', 8),
(27, 'Mini Chef', 9),
(28, 'Doctor Kit', 9),
(29, 'Market Play', 9),
(30, 'Speed Racer', 10),
(31, 'Bike Rider', 10),
(32, 'Scooter Champ', 10),
(33, 'Soccer Star', 11),
(34, 'Baseball Pro', 11),
(35, 'Basketball Ace', 11),
(36, 'Snuggle Pup', 12),
(37, 'Elephant Friend', 12),
(38, 'Lion King', 12),
(39, 'Race Car', 13),
(40, 'Monster Truck', 13),
(41, 'Fire Engine', 13),
(42, 'Dump Truck', 13),
(43, 'Cement Mixer', 13),
(44, 'Mini Piano', 14),
(45, 'Rock Guitar', 14),
(46, 'Drum Set', 14),
(47, 'Train Set', 15),
(48, 'Jet Plane', 15),
(49, 'Speed Boat', 15),
(50, 'Water Blaster', 16),
(51, 'Submarine', 16),
(52, 'Aqua Fish', 16),
(53, 'Wood Blocks', 17),
(54, 'Puzzle Pieces', 17),
(55, 'Wood Train', 17),
(56, 'Paint Kit', 18),
(57, 'Clay Set', 18),
(58, 'Bead Craft', 18),
(59, 'Chemistry Lab', 19),
(60, 'Physics Kit', 19),
(61, 'Bio Lab', 19),
(62, 'Drum Kit', 20),
(63, 'Flute Fun', 20),
(64, 'Xylo Tunes', 20),
(65, 'Dragon Slayer Deluxe', 1),
(66, 'Mystic Warrior Deluxe', 1),
(67, 'Galactic Hero Deluxe', 1),
(68, 'Shadow Ninja Deluxe', 1),
(69, 'Castle Builder Pro', 2),
(70, 'Space Explorer Pro', 2),
(71, 'Pirate Adventure Pro', 2),
(72, 'Princess Dream Deluxe', 3),
(73, 'Fairy Tale Deluxe', 3),
(74, 'Mermaid Magic Deluxe', 3),
(75, 'Alphabet Explorer Pro', 4),
(76, 'Number Wizard Pro', 4),
(77, 'Shape Shifter Pro', 4),
(78, 'Robo Buddy Pro', 5),
(79, 'Tech Genius Pro', 5),
(80, 'Gadget Guru Pro', 5),
(81, 'Mystery Quest Pro', 6),
(82, 'Card Master Pro', 6),
(83, 'Puzzle Pro Deluxe', 6),
(84, 'Brain Teaser Pro', 6),
(85, 'Slide Master Pro', 7),
(86, 'Swing King Pro', 7),
(87, 'Sand Castle Pro', 7),
(88, 'Cuddle Bear Pro', 8),
(89, 'Fluffy Bunny Pro', 8),
(90, 'Soft Kitty Pro', 8),
(91, 'Mini Chef Pro', 9),
(92, 'Doctor Kit Pro', 9),
(93, 'Market Play Pro', 9),
(94, 'Speed Racer Pro', 10),
(95, 'Bike Rider Pro', 10),
(96, 'Scooter Champ Pro', 10),
(97, 'Soccer Star Pro', 11),
(98, 'Baseball Pro Deluxe', 11),
(99, 'Basketball Ace Pro', 11),
(100, 'Snuggle Pup Pro', 12),
(101, 'Elephant Friend Pro', 12),
(102, 'Lion King Pro', 12),
(103, 'Race Car Pro', 13),
(104, 'Monster Truck Pro', 13),
(105, 'Fire Engine Pro', 13),
(106, 'Dump Truck Pro', 13),
(107, 'Cement Mixer Pro', 13),
(108, 'Mini Piano Pro', 14),
(109, 'Rock Guitar Pro', 14),
(110, 'Drum Set Pro', 14),
(111, 'Train Set Pro', 15),
(112, 'Jet Plane Pro', 15),
(113, 'Speed Boat Pro', 15),
(114, 'Water Blaster Pro', 16),
(115, 'Submarine Pro', 16),
(116, 'Aqua Fish Pro', 16),
(117, 'Wood Blocks Pro', 17),
(118, 'Puzzle Pieces Pro', 17),
(119, 'Wood Train Pro', 17),
(120, 'Paint Kit Pro', 18);

-- sales_region

INSERT INTO sales_region (sales_region_id, sales_region_name) VALUES
(1, 'North America'),
(2, 'Latin America'),
(3, 'Eastern Europe'),
(4, 'Western Europe'),
(5, 'Central Europe'),
(6, 'Northern Europe'),
(7, 'Southern Europe');

-- region

INSERT INTO region (country_id, country_name, sales_region_id) VALUES
(1, 'United States', 1),
(2, 'Canada', 1),
(3, 'Mexico', 2),
(4, 'Brazil', 2),
(5, 'Argentina', 2),
(6, 'Chile', 2),
(7, 'Colombia', 2),
(8, 'Peru', 2),
(9, 'Venezuela', 2),
(10, 'Poland', 3),
(11, 'Czech Republic', 3),
(12, 'Hungary', 3),
(13, 'Romania', 3),
(14, 'Bulgaria', 3),
(15, 'Slovakia', 3),
(16, 'Russia', 3),
(17, 'Germany', 4),
(18, 'France', 4),
(19, 'United Kingdom', 4),
(20, 'Italy', 4),
(21, 'Spain', 4),
(22, 'Netherlands', 4),
(23, 'Belgium', 4),
(24, 'Austria', 5),
(25, 'Switzerland', 5),
(26, 'Czech Republic', 5),
(27, 'Slovakia', 5),
(28, 'Denmark', 6),
(29, 'Sweden', 6),
(30, 'Norway', 6),
(31, 'Finland', 6),
(32, 'Ireland', 6),
(33, 'Portugal', 7),
(34, 'Greece', 7),
(35, 'Turkey', 7),
(36, 'Cyprus', 7);


-- sales

INSERT INTO toysales (order_number, order_linenumber, order_date, product_id, quantity, sales_amount, country_id) VALUES
('ORD001', 1, '2019-01-05', 12, 3, 45.00, 18),
('ORD002', 1, '2019-02-10', 23, 2, 30.00, 5),
('ORD003', 1, '2019-03-15', 34, 1, 15.75, 12),
('ORD004', 1, '2019-04-20', 45, 4, 60.00, 8),
('ORD005', 1, '2019-05-25', 56, 2, 25.50, 3),
('ORD006', 1, '2019-06-30', 67, 5, 75.00, 21),
('ORD007', 1, '2019-07-05', 78, 3, 45.00, 18),
('ORD008', 1, '2019-08-10', 89, 2, 30.00, 9),
('ORD009', 1, '2019-09-15', 101, 1, 15.00, 27),
('ORD010', 1, '2019-10-20', 112, 4, 60.00, 8),
('ORD011', 1, '2019-11-25', 103, 2, 25.50, 3),
('ORD012', 1, '2019-12-05', 34, 5, 75.00, 21),
('ORD013', 1, '2019-12-10', 45, 3, 45.00, 18),
('ORD014', 1, '2019-12-15', 56, 2, 30.00, 9),
('ORD015', 1, '2019-12-23', 67, 1, 15.00, 27),
('ORD016', 1, '2020-01-05', 12, 3, 45.00, 18),
('ORD017', 1, '2020-02-10', 23, 2, 30.00, 5),
('ORD018', 1, '2020-03-15', 34, 1, 15.75, 12),
('ORD019', 1, '2020-04-20', 45, 4, 60.00, 8),
('ORD020', 1, '2020-05-25', 56, 2, 25.50, 3),
('ORD021', 1, '2020-06-30', 67, 5, 75.00, 21),
('ORD022', 1, '2020-07-05', 78, 3, 45.00, 18),
('ORD023', 1, '2020-08-10', 89, 2, 30.00, 9),
('ORD024', 1, '2020-09-15', 101, 1, 15.00, 27),
('ORD025', 1, '2020-10-20', 112, 4, 60.00, 8),
('ORD026', 1, '2020-11-25', 120, 2, 25.50, 3),
('ORD027', 1, '2020-12-01', 34, 5, 75.00, 21),
('ORD028', 1, '2020-12-10', 45, 3, 45.00, 18),
('ORD029', 1, '2020-12-15', 56, 2, 30.00, 9),
('ORD030', 1, '2020-12-20', 67, 1, 15.00, 27),
('ORD031', 1, '2021-01-05', 12, 3, 45.00, 18),
('ORD032', 1, '2021-02-10', 23, 2, 30.00, 5),
('ORD033', 1, '2021-03-15', 34, 1, 15.75, 12),
('ORD034', 1, '2021-04-20', 45, 4, 60.00, 8),
('ORD035', 1, '2021-05-25', 56, 2, 25.50, 3),
('ORD036', 1, '2021-06-30', 67, 5, 75.00, 21),
('ORD037', 1, '2021-07-05', 78, 3, 45.00, 18),
('ORD038', 1, '2021-08-10', 89, 2, 30.00, 9),
('ORD039', 1, '2021-09-15', 101, 1, 15.00, 27),
('ORD040', 1, '2021-10-20', 112, 4, 60.00, 8),
('ORD041', 1, '2021-11-25', 119, 2, 25.50, 3),
('ORD042', 1, '2021-12-03', 34, 5, 75.00, 21),
('ORD043', 1, '2021-12-10', 45, 3, 45.00, 18),
('ORD044', 1, '2021-12-15', 56, 2, 30.00, 9),
('ORD045', 1, '2021-12-20', 67, 1, 15.00, 27),
('ORD046', 1, '2022-01-05', 12, 3, 45.00, 18),
('ORD047', 1, '2022-02-10', 23, 2, 30.00, 5),
('ORD048', 1, '2022-03-15', 34, 1, 15.75, 12),
('ORD049', 1, '2022-04-20', 45, 4, 60.00, 8),
('ORD050', 1, '2022-05-25', 56, 2, 25.50, 3),
('ORD051', 1, '2022-06-30', 67, 5, 75.00, 21),
('ORD052', 1, '2022-07-05', 78, 3, 45.00, 18),
('ORD053', 1, '2022-08-10', 89, 2, 30.00, 9),
('ORD054', 1, '2022-09-15', 101, 1, 15.00, 27),
('ORD055', 1, '2022-10-20', 112, 4, 60.00, 8),
('ORD056', 1, '2022-11-25', 13, 2, 25.50, 3),
('ORD057', 1, '2022-12-03', 34, 5, 75.00, 21),
('ORD058', 1, '2022-12-06', 45, 3, 45.00, 18),
('ORD059', 1, '2022-12-22', 56, 2, 30.00, 9),
('ORD060', 1, '2022-12-22', 67, 1, 15.00, 27),
('ORD061', 1, '2023-01-05', 12, 3, 45.00, 18),
('ORD062', 1, '2023-02-10', 23, 2, 30.00, 5),
('ORD063', 1, '2023-03-15', 34, 1, 15.75, 12),
('ORD064', 1, '2023-04-20', 45, 4, 60.00, 8),
('ORD065', 1, '2023-05-25', 56, 2, 25.50, 3),
('ORD066', 1, '2023-06-30', 67, 5, 75.00, 21),
('ORD067', 1, '2023-07-05', 78, 3, 45.00, 18),
('ORD068', 1, '2023-08-10', 89, 2, 30.00, 9),
('ORD069', 1, '2023-09-15', 101, 1, 15.00, 27),
('ORD070', 1, '2023-10-20', 112, 4, 60.00, 8),
('ORD071', 1, '2023-11-25', 114, 2, 25.50, 3),
('ORD072', 1, '2023-12-01', 34, 5, 75.00, 21),
('ORD073', 1, '2023-12-10', 45, 3, 45.00, 18),
('ORD074', 1, '2023-12-15', 56, 2, 30.00, 9),
('ORD075', 1, '2023-12-20', 67, 1, 15.00, 27),
('ORD076', 1, '2024-01-05', 12, 3, 45.00, 18),
('ORD077', 1, '2024-02-10', 23, 2, 30.00, 5),
('ORD078', 1, '2024-03-15', 34, 1, 15.75, 12),
('ORD079', 1, '2024-04-20', 45, 4, 60.00, 8),
('ORD080', 1, '2024-05-25', 56, 2, 25.50, 3),
('ORD081', 1, '2024-06-30', 67, 5, 75.00, 21),
('ORD082', 1, '2024-07-05', 78, 3, 45.00, 18),
('ORD083', 1, '2024-08-10', 89, 2, 30.00, 9),
('ORD084', 1, '2024-09-15', 101, 1, 15.00, 27),
('ORD085', 1, '2024-10-20', 112, 4, 60.00, 8),
('ORD086', 1, '2024-11-25', 19, 2, 25.50, 3),
('ORD087', 1, '2024-12-03', 34, 5, 75.00, 21),
('ORD088', 1, '2024-12-02', 45, 3, 45.00, 18),
('ORD089', 1, '2024-12-16', 56, 2, 30.00, 9),
('ORD090', 1, '2024-12-19', 67, 1, 15.00, 27);


-- Task 4
-- 1)	Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata). 
-- category table
SELECT category_id
FROM category as c
GROUP BY 1
HAVING COUNT(*) > 1;
-- Soluzione alternativa
DESCRIBE category;

-- products table
SELECT product_id
FROM products as p
GROUP BY 1
HAVING COUNT(*) > 1;
-- Soluzione alternativa
DESCRIBE products;

-- sales_region table
SELECT sales_region_id 
FROM sales_region
GROUP BY 1
HAVING COUNT(*) > 1;
-- Soluzione alternativa
DESCRIBE sales_region;

-- region table
SELECT country_id 
FROM region
GROUP BY 1
HAVING COUNT(*) > 1;
-- Soluzione alternativa
DESCRIBE region;

-- toysales table
SELECT CONCAT(order_number, order_linenumber) 
FROM toysales
GROUP BY 1
HAVING COUNT(*) > 1;
-- Soluzione alternativa
DESCRIBE toysales;

-- 2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, 
-- la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)

SELECT ts.order_number,
ts.order_date, 
p.product_name,
c.category_name, 
sr.sales_region_name,
CURDATE() AS today,
CASE
	WHEN DATEDIFF(CURDATE(), ts.order_date) > '180' THEN 'True'
    ELSE 'False'
END AS return_timewindow
FROM toysales ts
JOIN products p
ON ts.product_id = p.product_id
JOIN category c
ON p.category_id = c.category_id
JOIN region r
ON ts.country_id = r.country_id
JOIN sales_region sr
ON r.sales_region_id = sr.sales_region_id
ORDER BY order_date DESC;

-- 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
-- (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto.

SELECT product_id,
SUM(sales_amount) AS total_sales
FROM toysales
WHERE YEAR(order_date) LIKE '2024'
GROUP BY product_id
HAVING total_sales >= (SELECT AVG(sales_amount) 
						FROM toysales WHERE YEAR(order_date) LIKE '2024')
ORDER BY total_sales DESC;

-- 4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT p.product_name,
YEAR(ts.order_date) AS year,
SUM(ts.sales_amount) AS total_sales
FROM toysales ts
LEFT JOIN products p
ON ts.product_id = p.product_id
GROUP BY p.product_name, year; 

-- 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT r.country_name AS country_name,
YEAR(ts.order_date) AS year,
SUM(ts.sales_amount) as total_sales
FROM toysales ts
LEFT JOIN region r
ON ts.country_id = r.country_id
GROUP BY country_name, year
ORDER BY year DESC, total_sales DESC;

-- 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT c.category_name AS category_name,
SUM(ts.quantity) AS total_quantity
FROM toysales ts
LEFT JOIN products p
ON ts.product_id = p.product_id
JOIN category c
ON p.category_id = c.category_id
GROUP BY p.category_id
ORDER BY total_quantity DESC;

-- La categoria più richiesta è Toy Instruments

-- 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

SELECT p.product_name AS product_name
FROM products p
LEFT JOIN toysales ts
ON p.product_id = ts.product_id
WHERE ts.product_id IS NULL;

SELECT product_name
FROM products
WHERE product_id NOT IN (SELECT product_id FROM toysales);

-- 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)


CREATE VIEW productinfo AS 
(SELECT p.product_id AS product_id,
p.product_name AS product_name,
c.category_name AS category_name
FROM products p
JOIN category c
ON p.category_id = c.category_id
ORDER BY product_id DESC);

SELECT * FROM productinfo;

-- 9)	Creare una vista per le informazioni geografiche
-- Togliere commento per eseguire BP

CREATE VIEW geoinfo AS
(SELECT r.country_id AS country_id,
r.country_name AS country_name,
sr.sales_region_name AS sales_region_name
FROM region r
JOIN sales_region sr
ON r.sales_region_id = sr.sales_region_id
ORDER BY country_id);

SELECT * FROM geoinfo;
